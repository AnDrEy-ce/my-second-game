'use strict'
startGame();
let leftFish;
let topFish;
let counter = 0;
setFish();
let arrayForRockHide = document.querySelectorAll('hide');
document.addEventListener('keydown',gameControl);
let rocksSpawn = document.querySelectorAll('.spawnRock');
let arrayForRock = document.querySelectorAll('.rock');
let topPerson = getCoords(document.querySelector('.person')).top+45;
let leftPerson = getCoords(document.querySelector('.person')).left;
let topRock;
let leftRock;
leftFish = getCoords(document.querySelector('.fishPhoto')).left;
topFish = getCoords(document.querySelector('.fishPhoto')).top;
let timerTwo = setInterval(function intervalForRockTwo(event) {
   document.querySelectorAll('.rock').forEach(function (item) {
    topRock = getCoords(item).top;
    leftRock = getCoords(item).left;
    if((((Math.floor(Math.floor(topRock)/10)*10)+40 == topPerson) && (leftRock+2 == leftPerson)) || (((Math.floor(Math.floor(topRock)/10)*10)-40 == topPerson-40) && (leftRock+2 == leftPerson)) || (((Math.floor(Math.floor(topRock)/10)*10)+25 == topPerson+45) && (leftRock+2 == leftPerson))){
            document.querySelector('section').innerHTML = ``;
            document.querySelector('body div:first-child p').innerHTML = ``;
            clearInterval(timerTwo);
            clearInterval(timer);
            document.querySelector('body div:nth-child(2)').classList.toggle('hideForOver');
            document.querySelector('.gameOver').insertAdjacentHTML(`afterbegin`,`<h2>Ты проиграл.Твой счёт ${counter}</h2><button>Заново</button>`);
            document.querySelector('button').addEventListener('click',function(event) {
                location.reload()
            })

        }
        })   
},0);
                                                                                                                 // Выполняет функцию с определённым интервалом(clearInterval(timer)остановит функцию)
let timer = setInterval(function intervalForRock(event) {
    let rock = getRandomIntInclusive(0,document.querySelectorAll('.spawnRock').length-11);
    rocksSpawn[rock].insertAdjacentHTML('afterbegin',`<img src="img/rock.jpg" class='rock' alt="картинка">`);
    arrayForRockHide = document.querySelectorAll('.hide');
},600);
// Сама игра
function gameControl(event) {
    let positionLeft = document.querySelector('.person').offsetLeft;
    let positionTop = document.querySelector('.person').offsetTop;
    let allRock = document.querySelectorAll('.rock');
    switch (event.keyCode) {
        case 37:
            allRock.forEach(item => {
                if(item.offsetTop == 560){
                    item.classList.toggle('hide')
                }
            })
                                                                                                                                      // спавн камней при нажатии на кнопки
            // rocksSpawn[rock].insertAdjacentHTML('afterbegin',`<img src="img/rock.jpg" class='rock' alt="картинка">`);
            if(positionLeft == 2){
                document.querySelector('.person').style.left = `${positionLeft+450}px`;
            }else{
                document.querySelector('.person').style.left = `${positionLeft-50}px`;
            }
            // console.log(getCoords(document.querySelector('.person')).top);
            topPerson = getCoords(document.querySelector('.person')).top;
            leftPerson = getCoords(document.querySelector('.person')).left;
            // console.log(topPerson);
            clear(arrayForRockHide);
            check();
            break;
        case 38:
            allRock.forEach(item => {
                if(item.offsetTop == 560){
                    item.classList.toggle('hide')
                }
            })  
                                                                                                                                        // спавн камней при нажатии на кнопки
            // rocksSpawn[rock].insertAdjacentHTML('afterbegin',`<img src="img/rock.jpg" class='rock' alt="картинка">`);

            if(positionTop == 52){
                document.querySelector('.person').style.top = `${positionTop+450}px`;
            }else{
                document.querySelector('.person').style.top = `${positionTop-50}px`;
            }
            topPerson = getCoords(document.querySelector('.person')).top;
            leftPerson = getCoords(document.querySelector('.person')).left;
            clear(arrayForRockHide);
            check();
            break;
        case 39:
            allRock.forEach(item => {
                if(item.offsetTop == 560){
                    item.classList.toggle('hide')
                }
            })
                                                                                                                                        // спавн камней при нажатии на кнопки
            // rocksSpawn[rock].insertAdjacentHTML('afterbegin',`<img src="img/rock.jpg" class='rock' alt="картинка">`);   
            if(positionLeft == 452){
                document.querySelector('.person').style.left = `${positionLeft-450}px`;
            }else{
                document.querySelector('.person').style.left = `${positionLeft+50}px`;
            }
            topPerson = getCoords(document.querySelector('.person')).top;
            leftPerson = getCoords(document.querySelector('.person')).left;
            clear(arrayForRockHide);
            check();
            break;
        case 40:
            allRock.forEach(item => {
                if(item.offsetTop == 560){
                    item.classList.toggle('hide')
                }
            })
                                                                                                                                             // спавн камней при нажатии на кнопки
            // rocksSpawn[rock].insertAdjacentHTML('afterbegin',`<img src="img/rock.jpg" class='rock' alt="картинка">`);  
            if(positionTop == 502){
                document.querySelector('.person').style.top = `${positionTop-450}px`;
            }else{
                document.querySelector('.person').style.top = `${positionTop+50}px`;
            }
            topPerson = getCoords(document.querySelector('.person')).top;
            leftPerson = getCoords(document.querySelector('.person')).left;
            clear(arrayForRockHide);
            check();
            break;   
    }
}
function getRandomIntInclusive(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min; //Максимум и минимум включаются
  }
                                                                                                                                                //   спавн камней с интервалом
function startGame() {
    let person = getRandomIntInclusive(0,document.querySelectorAll('.gameCell:not(.spawnRock)').length-1);
    document.querySelectorAll('.gameCell:not(.spawnRock)')[person].insertAdjacentHTML('afterbegin',`<img src="img/пингвин.jpg" class='person' alt="картинка">`)

}
function getCoords(elem) { 
    var box = elem.getBoundingClientRect();
    return {
      top: box.top + scrollY,
      left: box.left + scrollX
    };
  }
function clear(arr) {
   arr.forEach(item => item.remove())
}
function setFish(params) {
    let beach = getRandomIntInclusive(0,document.querySelectorAll('.gameCell:not(.spawnRock)').length-1);
    document.querySelectorAll('.gameCell:not(.spawnRock)')[beach].classList.add('fish');
    document.querySelectorAll('.gameCell:not(.spawnRock)')[beach].insertAdjacentHTML('afterbegin',`<img src='img/fish.jpg' class='fishPhoto '>`)
    leftFish = getCoords(document.querySelector('.fishPhoto')).left;
    topFish = getCoords(document.querySelector('.fishPhoto')).top;
}
function check(params) {
    if((topFish == topPerson) && (leftFish == leftPerson)){
        if(counter == 9){
            document.querySelector('section').innerHTML = ``;
            document.querySelector('body div:first-child p').innerHTML = ``;
            clearInterval(timerTwo);
            clearInterval(timer);
            document.querySelector('body div:nth-child(2)').classList.toggle('hideForOver');
            document.querySelector('.gameOver').insertAdjacentHTML(`afterbegin`,`<h2>Ты победил.Твой счёт ${counter+1}</h2><button>Заново</button>`);
            document.querySelector('button').addEventListener('click',function(event) {
                location.reload()
            })

        }else{
        document.querySelector('.fishPhoto').remove();
        document.querySelector('.fish').classList.remove('fish');
        counter++
        document.querySelector('body div:first-child p').innerHTML = `Счёт ${counter}`
        setFish();
        }
    }
}

